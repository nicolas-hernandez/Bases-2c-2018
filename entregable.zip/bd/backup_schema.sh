#!/usr/bin/env bash
pg_dump --column-inserts --schema-only tp1_bd
