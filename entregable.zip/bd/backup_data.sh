#!/usr/bin/env bash
pg_dump --column-inserts --data-only tp1_bd
